import Main from "./_component/Main";

export default function Home() {
  return <Main />;
}
