export default function LoginModal() {

    return (
        <>
            <div>
                로그인모달입니다.
            </div>
        </>
    )
}