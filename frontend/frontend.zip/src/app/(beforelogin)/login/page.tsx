import LoginModal from "@/app/(beforelogin)/_component/LoginModal"

export default function Login() {
    return (
        <>
            <LoginModal />
        </>
    )
}