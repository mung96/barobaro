import LoginModal from "@/app/(beforelogin)/_component/LoginModal"

export default function Login() {
    return (
        <>
            로그인모달입니다.
        </>
    )
}