// import Card from './(recent_list_component)/Card'
// import {ScrollMenu} from 'react-horizontal-scrolling-menu'
//
//
//
// export default function RecentPostList() {
//
//     return (
//         <ScrollMenu>
//
//         </ScrollMenu>
//     )
// }