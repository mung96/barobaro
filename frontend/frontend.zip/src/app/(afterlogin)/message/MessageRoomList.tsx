'use client';

import Image from 'next/image';

export default function MessageRoomList() {
  return (
    // <div className="mt-[2vh]">
    //   <div className="flex justify-start items-center justify-center w-full h-[12vh] bg-gray-100">
    //     <div className="relative w-[15%] h-[75%]">
    //       <Image
    //         src="/cat.jpg" // public 폴더 내의 이미지 경로
    //         alt="Cat" // 이미지 설명 추가
    //         layout="fill" // 부모 div의 크기에 맞게 이미지가 채워지도록 설정
    //         objectFit="cover" // 이미지 비율 유지하면서 부모 div에 맞게 채움
    //         className="rounded-full" // 원형으로 만들기
    //       />
    //     </div>
    //   </div>
    // </div>
    <div className="mt-[2vh] ">
      <div className="bg-blue-200">
        <div className="flex gap-0 p-4">
          {/* 왼쪽 이미지 */}
          <div className="w-2/12 flex items-center justify-center">
            <div className="relative rounded-full overflow-hidden bg-gray-100">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Left Cat" // 이미지 설명 추가
                layout="responsive" // 이미지의 원본 크기에 맞게 표시
                width={200}
                height={200}
                className="object-cover" // 이미지 비율 유지 및 컨테이너에 맞게 채우기
              />
            </div>

            {/* <div className="relative rounded-full aspect-w-1 aspect-h-1 overflow-hidden bg-gray-100">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Left Cat" // 이미지 설명 추가
                layout="fill" // 부모 요소에 맞게 이미지 크기를 조절
                className="object-cover" // 이미지 비율 유지 및 컨테이너에 맞게 채우기
              />
            </div> */}
          </div>

          {/* 가운데 텍스트 영역 */}
          <div className="w-8/12 flex flex-col justify-start bg-gray-100 p-2">
            <p className="font-bold">위쪽 텍스트</p>
            <p className="text-xs">아래쪽 텍스트</p>
          </div>

          {/* 오른쪽 이미지 */}
          <div className="w-2/12 flex items-center justify-center bg-gray-100">
            <div className="relative w-full h-full">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Right Cat" // 이미지 설명 추가
                layout="fill" // 부모 div의 크기에 맞게 이미지가 채워지도록 설정
                objectFit="cover" // 이미지 비율 유지하면서 부모 div에 맞게 채움
                className="rounded-full" // 원형으로 만들기
              />
            </div>
          </div>
        </div>
      </div>

      <div className=" bg-blue-500">
        <div className="grid grid-cols-12 gap-4 p-4">
          {/* 왼쪽 이미지 */}
          <div className="col-span-2 flex items-center justify-center bg-gray-100">
            <div className="relative w-full h-full">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Left Cat" // 이미지 설명 추가
                layout="fill" // 부모 div의 크기에 맞게 이미지가 채워지도록 설정
                objectFit="cover" // 이미지 비율 유지하면서 부모 div에 맞게 채움
                className="rounded-full" // 원형으로 만들기
              />
            </div>
          </div>

          {/* 가운데 텍스트 영역 */}
          <div className="col-span-8 flex flex-col justify-start bg-gray-100 p-2">
            <p className="font-bold">위쪽 텍스트</p>
            <p className="text-xs">아래쪽 텍스트</p>
          </div>

          {/* 오른쪽 이미지 */}
          <div className="col-span-2 flex items-center justify-center bg-gray-100">
            <div className="relative w-full h-full">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Right Cat" // 이미지 설명 추가
                layout="fill" // 부모 div의 크기에 맞게 이미지가 채워지도록 설정
                objectFit="cover" // 이미지 비율 유지하면서 부모 div에 맞게 채움
                className="rounded-full" // 원형으로 만들기
              />
            </div>
          </div>
        </div>
      </div>

      <div className=" bg-blue-700">
        <div className="grid grid-cols-12 gap-4 p-4">
          {/* 왼쪽 이미지 */}
          <div className="col-span-2 flex items-center justify-center bg-gray-100">
            <div className="relative w-full h-full">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Left Cat" // 이미지 설명 추가
                layout="fill" // 부모 div의 크기에 맞게 이미지가 채워지도록 설정
                objectFit="cover" // 이미지 비율 유지하면서 부모 div에 맞게 채움
                className="rounded-full" // 원형으로 만들기
              />
            </div>
          </div>

          {/* 가운데 텍스트 영역 */}
          <div className="col-span-8 flex flex-col justify-start bg-gray-100 p-2">
            <p className="font-bold">위쪽 텍스트</p>
            <p className="text-xs">아래쪽 텍스트</p>
          </div>

          {/* 오른쪽 이미지 */}
          <div className="col-span-2 flex items-center justify-center bg-gray-100">
            <div className="relative w-full h-full">
              <Image
                src="/cat.jpg" // public 폴더 내의 이미지 경로
                alt="Right Cat" // 이미지 설명 추가
                layout="fill" // 부모 div의 크기에 맞게 이미지가 채워지도록 설정
                objectFit="cover" // 이미지 비율 유지하면서 부모 div에 맞게 채움
                className="rounded-full" // 원형으로 만들기
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
