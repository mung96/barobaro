type LentInfo = {
  title: string;
  period: string;
};

type UserInfo = {
  // 유저 정보
};

type Message = {
  type: number;
  user: UserInfo;
  body?: string;
  info?: LentInfo;
  timestamp: string;
};

export default function Message({
  type,
  user,
  body,
  info,
  timestamp,
}: Message) {
  // 메시지 타입에 따라 처리 분리
}
