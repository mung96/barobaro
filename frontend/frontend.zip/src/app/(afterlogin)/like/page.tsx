export default function Like() {
    return (
        <>
            Like
        </>
    )
}