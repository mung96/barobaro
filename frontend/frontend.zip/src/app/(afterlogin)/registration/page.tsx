export default function Registration() {
    return (
        <>
            Registration
        </>
    )
}