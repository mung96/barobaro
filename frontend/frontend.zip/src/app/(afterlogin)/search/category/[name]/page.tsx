export default function CategoryDetail() {
    return (
        <>
            <div>
                category - name - page.tsx
            </div>
        </>
    )
}