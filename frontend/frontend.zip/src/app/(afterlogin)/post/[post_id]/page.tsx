export default function PostDetail() {
    return (
        <>
            여기는 게시물 내용이 표시되는 공간
        </>
    )
}