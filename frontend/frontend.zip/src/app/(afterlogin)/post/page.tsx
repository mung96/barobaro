export default function Post() {
    return (
        <>
            Post
        </>
    )
}